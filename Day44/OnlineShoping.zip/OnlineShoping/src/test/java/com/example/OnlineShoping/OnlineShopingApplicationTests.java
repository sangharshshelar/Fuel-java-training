package com.example.OnlineShoping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShopingApplicationTests {

	@Test
	void contextLoads() {
	}

}
