package com.example.ApplicationMangerJpaDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationMangerJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
